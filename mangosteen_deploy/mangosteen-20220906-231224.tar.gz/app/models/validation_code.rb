class ValidationCode < ApplicationRecord
end
